/**
 * This is a generated file. Do not edit or your changes will be lost
 */
#import "TiGeoloqiModuleAssets.h"

extern NSData * dataWithHexString (NSString * hexString);

@implementation TiGeoloqiModuleAssets

- (NSData*) moduleAsset
{
	return nil;
}

@end
