//
//  LQSDKVersion.h
//  GeoloqiSDK
//
//  Copyright (c) 2012 Geoloqi, Inc. All rights reserved.
//

static NSString *const LQSDKNameString = @"com.geoloqi.titanium.iphone";
// static NSString *const LQSDKNameString = @"com.geoloqi.iphone";

static NSString *const LQSDKVersionString = @"12.296";

// This build string is automatically updated when the sdk is built! Do not modify.
static NSString *const LQSDKVersionGitVersion = @"2490322cc03723e0524808fb73a2d7087f1a6965";
