# Geoloqi iPhone Titanium Module

This is the source code to the Geoloqi iPhone Titanium Module. This was not developed in house at Geoloqi, and is no longer supported by Geoloqi. This code has been released under the Apache license.


