Geoloqi Android SDK module for Titanium.

This was not developed in house at Geoloqi, and is no longer supported by Geoloqi.  This code has been released under the Apache license.

## Building

To build the Titanium module you first need to make sure you have
the Titanium cli tools installed and have created a valid `build.properties`
file.

You can copy the `build.properties.sample` file to `build.properties` and
update it with your local paths.

You can then build the module by running the `ant` command from the
terminal:

    $ ant

If the build succeeds it will output the built module into the `dist`
directory.
